package br.fiap.cliente;

public class Cliente {

	int id;
	String nome;
	String PF, PJ;

	public Cliente(int id, String nome, String pF, String pJ) {
		super();
		this.id = id;
		this.nome = nome;
		this.PF = pF;
		this.PJ = pJ;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getPF() {
		return PF;
	}

	public void setPF(String pF) {
		this.PF = pF;
	}

	public String getPJ() {
		return PJ;
	}

	public void setPJ(String pJ) {
		this.PJ = pJ;
	}

	@Override
	public String toString() {
		String aux = "";
		aux += "Nome: " + nome + "\n";
		aux += "Pessoa Fésica: " + "\n";
		aux += "Pessoa Jurídica: " + "\n";
		return aux;
	}

}
