package br.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import br.fiap.cliente.Cliente;
import br.fiap.conexao.Conexao;

public class ClienteDAO {

	private Connection connection;
	private PreparedStatement ps;
	private ResultSet rs;
	private String sql;

	public boolean pesquisarCliente(int id) {
		connection = new Conexao().conectar();
		sql = "select * from cliente where numero = ?";
		boolean aux = false;

		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			aux = rs.next();
		} catch (SQLException e) {
			System.out.println("Erro ao pesquisar cliente\n" + e);
		}
		return aux;
	}

	public void inserirCliente(Cliente cliente) {
		connection = new Conexao().conectar();
		sql = "insert into cliente(nome,PF,PJ) values(?,?,?)";
		
		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, cliente.getNome());
			ps.setString(2, cliente.getPF());
			ps.setString(3, cliente.getPJ());
			ps.execute(); // ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Erro ao inserir cliente\n" + e);
		}
	}
	
	
}
