package br.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.fiap.conexao.Conexao;
import br.fiap.produto.Produto;

public class ProdutoDAO {

	private Connection connection;
	private PreparedStatement ps;
	private ResultSet rs;
	private String sql;

	public void inserirProduto(Produto prod) {
		connection = new Conexao().conectar();
		sql = "insert into produto(nome) values(?)";

		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, prod.getNome());
			ps.execute(); // ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Erro ao inserir produto pelo nome\n" + e);
		}

	}

	public boolean pesquisarProduto(int id) {
		connection = new Conexao().conectar();
		sql = "select * from produto where cpf = ?";
		boolean aux = false;

		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			aux = rs.next();
		} catch (SQLException e) {
			System.out.println("Erro ao pesquisar o produto pelo ID\n" + e);
		}
		return aux;
	}

	public List<Produto> listar() {
		List<Produto> lista = new ArrayList<Produto>();
		connection = new Conexao().conectar();
		sql = "select * from produto";

		try {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				lista.add(new Produto(rs.getInt("Id"), rs.getString("nome")));
			}

		} catch (SQLException e) {
			System.out.println("Erro ao pesquisar número do bilhete\n" + e);
		}

		return lista;

	}

}
