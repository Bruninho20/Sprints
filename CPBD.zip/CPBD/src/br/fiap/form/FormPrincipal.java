package br.fiap.form;

import static javax.swing.JOptionPane.*;
import static java.lang.Integer.parseInt;


public class FormPrincipal {
	

	public void menuPrincipal() {
		int opcao = 0;

		do {

			try {
				opcao=parseInt(showInputDialog(gerarMenuPrin()));
				switch (opcao) {
				case 1: {
					
					
				}
				default:
					
				}

			} catch (Exception e) {

			}

		} while (opcao != 3);

	}

	private String gerarMenuPrin() {
		String menu = "Escolha uma opção:\n";
		menu += "1 - Inserir Cliente\n";
		menu += "2 - Exibir Cliente\n";
		menu += "3 - Sair\n";
		return menu;
	}

}
